let html = require("./html");
function start(response) {
    run(response,  html.buildHtmlStart() )
}

function upload(response) {
    run(response,  html.buildHtmlUpload() )
}

function error404(response) {
    run(response,  html.buildHtml404() )
}

function run(response, msg){
    console.log(msg)
    response.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
    response.write( msg,'utf8' )
    response.end()
}

exports.start = start
exports.upload = upload
exports.error404 = error404
