let http = require("http")
let url = require("url")

function start(route, handle){
    http.createServer( onRequest ).listen(8787)
    console.log("Server started")

    function onRequest(request, response) {
        if (request.url.includes('favicon.ico')) {
            response.statusCode = 204
            response.end()
        } else {
            let pathname = url.parse(request.url).pathname
            route(handle, pathname, response)
        }
    }
}

exports.start = start