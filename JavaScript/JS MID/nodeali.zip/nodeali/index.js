let server = require("./server");
let router = require("./router");
let requestHandlers = require("./requestHandlers");

let handle = {
    '/' : requestHandlers.start,
    '/start' : requestHandlers.start, 
    '/upload' : requestHandlers.upload,
    '404': requestHandlers.error404,
}

server.start( router.route , handle );