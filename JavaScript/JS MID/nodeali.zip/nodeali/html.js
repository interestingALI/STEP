function buildHtmlStart() {
    let head = `<meta charset="UTF-8">
                <title>START page</title>
                <style>
                    body {
                        background: brown;
                        color: burlywood;
                    }
                </style>
`;
    let body = `<h1>Hello, СТАРТ</h1>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                <img src="https://vestikavkaza.ru/upload/fnorm/2020-11-09/16049443195fa981bf8e4595.43507965.jpg" alt="Shusha" />
`;
    return '<!DOCTYPE html>'
    + '<html><head>' + head + '</head><body>' + body + '</body></html>';
};

function buildHtmlUpload() {
    let head = `<meta charset="UTF-8">
                <title>Upload page</title>
                <style>
                    body {
                        background: purple;
                        color: lightblue;
                    }
                    p {
                        color: white
                    }    
                </style>
`;
    let body = `<h1>Hello, ЗАГРУЗЧИК</h1>
                <input type="file">
                <p>Текст-заполнитель — это текст, который имеет некоторые характеристики реального письменного текста, но является случайным набором слов или сгенерирован иным образом. Его можно использовать для отображения образца шрифтов, создания текста для тестирования или обхода спам-фильтра.</p>
                <img src="https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" alt="Party" />
`;
    return '<!DOCTYPE html>'
    + '<html><head>' + head + '</head><body>' + body + '</body></html>';
};

function buildHtml404() {
    let head = `<title>ERROR 404</title>
                <style>
                body, html {
                    height: 100%;
                    margin: 0;
                }
                
                .bg {
                    background-image: url("https://www.artzstudio.com/content/images/wordpress/2020/05/404-error-not-found-page-lost.png");
                    height: 100%; 
                    background-position: center;
                    background-repeat: no-repeat;
                }
                </style>
    `;

    let body = `<div class="bg"></div>`    
    return '<!DOCTYPE html>'
    + '<html><head>' + head + '</head><body>' + body + '</body></html>';
};

exports.buildHtmlStart = buildHtmlStart;
exports.buildHtmlUpload = buildHtmlUpload;
exports.buildHtml404 = buildHtml404;