function route(handle, pathname, response) {
    if ( typeof handle[pathname] === 'function' ) handle[pathname](response)
    else {
        console.log("Error 404 " + pathname + " not found.")
        handle["404"](response)
    }
}

exports.route = route;